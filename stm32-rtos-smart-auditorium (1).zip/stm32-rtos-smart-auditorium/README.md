# RTOS-Controlled Intelligent Space Utilization and Display System for Auditoriums Using STM32

## Overview
This repository documents an STM32-based concept for intelligent auditorium space utilization and display management using a Real-Time Operating System (RTOS).

The intended application is to organize occupancy-related information and present auditorium status through a display interface. Exact sensors, display hardware, RTOS, task priorities, and implemented behavior must be confirmed from the project report before this description is treated as a record of the final implementation.

## Objectives
- Explore embedded system design using an STM32 microcontroller.
- Demonstrate the structural difference between bare-metal polling and RTOS task-based program organization.
- Provide a place for project documentation, hardware details, and media.

## Repository Structure
- `docs/` — project report, block diagram, architecture diagram, and workflow (to be added).
- `firmware/` — separate bare-metal and RTOS starter examples.
- `hardware/` — verified component list, wiring, and pin mapping (to be added).
- `media/` — prototype photographs and screenshots (to be added).

## Firmware Status
The files in `firmware/` are **new starter implementations**, not recovered original firmware. `baremetal_main.c` uses direct STM32 register access via CMSIS device definitions; `rtos_main.c` illustrates a FreeRTOS task architecture and includes explicit integration hooks for sensor timing and LCD driver functions. Both assume a proposed pin map for the STM32F407VGT6, not verified original wiring. They have not been hardware-tested.

No claim is made that these templates have been compiled, tested, or validated on hardware.

## Build Notes
1. Create or open an STM32CubeIDE project for the exact STM32 part and board.
2. Configure clocks and required GPIO/peripherals using the board's actual wiring.
3. For `baremetal_main.c`, use an STM32F407 CMSIS/device-header project with startup files and linker script; it does not use HAL.
4. For `rtos_main.c`, add the FreeRTOS kernel/port and complete the sensor timing and LCD driver integration hooks.
5. Do not compile both files as separate application entry points in the same build. Confirm the actual wiring and test safely on hardware before claiming operation.

## Author
Electronics and Communication Engineering
